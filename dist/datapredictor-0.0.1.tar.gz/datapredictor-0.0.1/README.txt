First, check out the documentation on how this package works:👇👇👇

https://medium.com/@actualnew001/my-data-predictor-python-packet-a99b12395dfc